import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.process.ImageProcessor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import uk.co.caprica.vlcj.binding.LibVlc;
import uk.co.caprica.vlcj.binding.internal.libvlc_state_t;
import uk.co.caprica.vlcj.component.EmbeddedMediaPlayerComponent;
import uk.co.caprica.vlcj.runtime.RuntimeUtil;
import uk.co.caprica.vlcj.runtime.windows.WindowsRuntimeUtil;

import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;


public class MVFGLogic {
	
	private EmbeddedMediaPlayerComponent mediaPlayerComponent = null;
	
	private String mrl;
	private ImageStack imageStack;
	private HashMap<Integer, Float> frameOrder;

	public MVFGLogic(){
		try {
			String pathLib = URLDecoder.decode(MVFG_.class.getProtectionDomain().getCodeSource().getLocation().getPath(), "UTF-8").replace("MVFG_.jar", "MVFG_/lib");
			NativeLibrary.addSearchPath(RuntimeUtil.getLibVlcLibraryName(), pathLib);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		if(RuntimeUtil.isMac()){
			NativeLibrary.addSearchPath(RuntimeUtil.getLibVlcLibraryName(), "/Applications/VLC.app/Contents/MacOS/lib");
		}
		else if(RuntimeUtil.isWindows()){
			NativeLibrary.addSearchPath(RuntimeUtil.getLibVlcLibraryName(), WindowsRuntimeUtil.getVlcInstallDir());
		}
		else if(RuntimeUtil.isNix()){
			NativeLibrary.addSearchPath(RuntimeUtil.getLibVlcLibraryName(), "/home/linux/vlc/lib");
		}	

		Native.loadLibrary(RuntimeUtil.getLibVlcLibraryName(), LibVlc.class);
	    
	    imageStack = null;
	    mrl=null;
	    mediaPlayerComponent = new EmbeddedMediaPlayerComponent();
	    frameOrder = new HashMap<Integer, Float>();
	}

	public String getMrl() {
		return mrl;
	}

	public void setMrl(String mrl) {
		this.mrl = mrl;
	}

	public ImageStack getStacknova() {
		return imageStack;
	}

	public void setStacknova(ImageStack stacknova) {
		this.imageStack = stacknova;
	}

	public void setMediaPlayerComponent(
			EmbeddedMediaPlayerComponent mediaPlayerComponent) {
		this.mediaPlayerComponent = mediaPlayerComponent;
	}
	
	public EmbeddedMediaPlayerComponent getMediaPlayerComponent(){
		return mediaPlayerComponent;
	}
	
	public void setMediaPlayerPosition(float positionValue){
		mediaPlayerComponent.getMediaPlayer().setPosition(positionValue);
		mediaPlayerComponent.getMediaPlayer().play();
	}
	
	public boolean playMedia(){
		if(mrl!=null){
			//mediaPlayerComponent.getMediaPlayer().playMedia(this.mrl);
			//IJ.error(mrl);
			String[] mediaOptions = {};
			mediaPlayerComponent.getMediaPlayer().playMedia(this.mrl, mediaOptions);
			return true;
		}else return false;
	}
	
	public boolean endOfFile(){
		if(mediaPlayerComponent.getMediaPlayer().getMediaState()==libvlc_state_t.libvlc_Ended){
	    	  mediaPlayerComponent.getMediaPlayer().stop();
	    	  return true;
	    }else return false;
	}
	
	public int getPosition(){
		return (int)Math.round(mediaPlayerComponent.getMediaPlayer().getPosition()*1000);
	}
	
	public void checkMediaPlayerIsPlaying(){
		if (mediaPlayerComponent.getMediaPlayer().isPlaying())
			mediaPlayerComponent.getMediaPlayer().pause();
	}
	
	public boolean updatePosition(float position){
		float positionValue = position / 1000.0f;
		if (positionValue > 0.99f) {
			positionValue = 0.99f;
		}
		setMediaPlayerPosition(positionValue);
		return true;
	}
	
	public boolean openVideoPath(String path) {
		mediaPlayerComponent.getMediaPlayer().stop();
		mrl = path;
		File file = new File(mrl);
		if (file.exists() && !file.isDirectory()){
			return true;			    
		}else{
			mrl=null;
			return false;
		}	
	}
	
	public HashMap<String, Integer> aboutVideo(){
		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		hm.put("fps", (int) Math.round(mediaPlayerComponent.getMediaPlayer().getFps()));
		hm.put("time", (int) (mediaPlayerComponent.getMediaPlayer().getLength()/1000));
		BufferedImage bi = mediaPlayerComponent.getMediaPlayer().getSnapshot();
		hm.put("width", (int) bi.getWidth());
		hm.put("height", (int) bi.getHeight());
		return hm;
	}
	
	public JButton grabFrame() {	
		BufferedImage bi = mediaPlayerComponent.getMediaPlayer().getSnapshot();
		float time = mediaPlayerComponent.getMediaPlayer().getTime()/1000f;
		final ImagePlus iplus = new ImagePlus(String.valueOf(time+"s"), bi);

		ImageProcessor ip = iplus.getProcessor();
		
		if(imageStack==null) 
			imageStack = new ImageStack(ip.getWidth(),ip.getHeight());
		
		if(getFramePosition(time)!=-1) return null;
		
		OrderFrames of = new OrderFrames(time, ip);
		of.run();
		
		JButton te=new JButton(Float.toString(time), new ImageIcon(getThumbnail(ip)));
		te.setActionCommand(Float.toString(time));
		
		te.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent event) {
				float numSlice=Float.parseFloat(event.getActionCommand());
				ImageStack iStack = getImagePlusDuplicate().getStack();
				int a=1;
				for(a=1;a<=frameOrder.size();a++){
					if(frameOrder.get(a)==numSlice) break;
				}
				ImageProcessor ip = iStack.getProcessor(a);
				ImagePlus IPPosition = new ImagePlus("Frame "+numSlice,ip);
				IPPosition.show();
			}			
		});	
		return te;
	}
	
	private BufferedImage getThumbnail(ImageProcessor ip){
		ip.setInterpolate(true);
		ImageProcessor thumbnail = ip.resize(100, 100);
		ImagePlus ipthumbnail = new ImagePlus("", thumbnail);
		return ipthumbnail.getBufferedImage();
	}
	
	public int getFramePosition(float time){
		int frame=-1;
		for(int pos=1;pos<=frameOrder.size();pos++){			
			if(frameOrder.get(pos)==time){
				frame=pos-1;
				break;
			}
		}
		return frame;
	}
	
	public void exportStack(){
		getImagePlusDuplicate().show();
	}
	
	private ImagePlus getImagePlusDuplicate(){
		ImagePlus is = new ImagePlus("Stack",imageStack);
		return is.duplicate();
	}
	
	public void lastFrame(){
		long time = mediaPlayerComponent.getMediaPlayer().getTime();
		mediaPlayerComponent.getMediaPlayer().setTime(time - 300);
	}
	
	public void nextFrame(){
		mediaPlayerComponent.getMediaPlayer().nextFrame();
	}
	
	public void pause(){
		mediaPlayerComponent.getMediaPlayer().pause();
		mediaPlayerComponent.getMediaPlayer().setRate((float) 1.0);
	}
	
	public void play(){
		mediaPlayerComponent.getMediaPlayer().play();
	}
	
	public String getStringTime(){
		float time = mediaPlayerComponent.getMediaPlayer().getTime();
		final Calendar cal = Calendar.getInstance();
    	cal.setTimeInMillis((long) time);
    	cal.set(Calendar.HOUR, cal.get(Calendar.HOUR)-1);
    	return new SimpleDateFormat("HH:mm:ss:SSS").format(cal.getTime());
	}
	
	public void slowMedia(){
		float rate=mediaPlayerComponent.getMediaPlayer().getRate();
		if(rate>-8.0){
			mediaPlayerComponent.getMediaPlayer().setRate(rate/2);					
		}
	}
	
	public void fastMedia(){
		float rate=mediaPlayerComponent.getMediaPlayer().getRate();
		if(rate<8.0){
			mediaPlayerComponent.getMediaPlayer().setRate(rate*2);					
		}
	}
	
	class OrderFrames implements Runnable{

		private Float time;
		private ImageProcessor ip;

		public OrderFrames(Float time, ImageProcessor ip){
			this.time=time;
			this.ip=ip;
		}
		
		@Override
		public void run() {
			if(frameOrder.size()==0){
				frameOrder.put(1, time);
				imageStack.addSlice(time+"s",ip);
			}
			else{
				if(!frameOrder.containsValue(time)){
					int positionFrame=1;
					for(positionFrame=1;positionFrame<=frameOrder.size();positionFrame++){
						if(time<frameOrder.get(positionFrame)) break;
					}
					HashMap<Integer, Float> frameOrderCopy = new HashMap<Integer, Float>();
					for(int j=1;j<positionFrame;j++){
						frameOrderCopy.put(j, frameOrder.get(j));
					}
					frameOrderCopy.put(positionFrame, time);
					imageStack.addSlice(time+"s",ip,positionFrame-1);
					for(int k=positionFrame+1;k<=frameOrder.size()+1;k++){
						frameOrderCopy.put(k, frameOrder.get(k-1));
					}
					frameOrder=frameOrderCopy;
				}
			}
		}
	}
}
