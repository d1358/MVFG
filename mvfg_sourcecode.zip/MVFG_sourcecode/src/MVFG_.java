import ij.IJ;
import ij.gui.GenericDialog;
import ij.io.OpenDialog;
import ij.plugin.PlugIn;
import ij.plugin.frame.PlugInFrame;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;

import uk.co.caprica.vlcj.runtime.RuntimeUtil;

public class MVFG_ extends PlugInFrame implements ActionListener, PlugIn {

	private static final long serialVersionUID = 1L;
	
	private MVFGLogic logic;
	private final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
	
	private JSlider position;
	private JScrollPane panelFrames;
	private JSeparator separator;
	private JButton nf,lf,pausePlay,fv,sv;
	private JPanel pa;
	private JTextField tfpath;
	private JLabel timeLabel;
	
	private static Frame frame;
	private Panel panel, panelVideo;
	private Label label;
	private Button bOpen,bOpenVideo,bAbout,bPref,bFG,bES;
	private Icon playIcon, pauseIcon, lastIcon, nextIcon, fastIcon, slowIcon;
	
	private int widthApp, heightApp;

	public MVFG_() {
		super("Multi-format Video Frame Grabber - MVFG");
		frame = this;
		
		logic = new MVFGLogic();
	    
		initVar();
		initComponents();
	}

	private void initVar() {
		widthApp = 800;
		heightApp = 600;
	}

	private void initComponents(){
		panel = new Panel();
		panel.setLayout(null);
		
		addFilePathTextField();
		bOpen = new Button("Open");
		addButton(82, 10, 55, 28, bOpen);
		bOpen.setEnabled(false);
		
		bOpenVideo = new Button("...");
		addButton(140, 10, 55, 29, bOpenVideo);
		bOpenVideo.setActionCommand("Open Video");
		
		bAbout = new Button("About Video");
		addButton(widthApp-218, 10, 101, 28, bAbout);
		bAbout.setEnabled(false);
		
		bPref = new Button("Preferences");
		addButton(widthApp-111, 10, 101, 28, bPref);
		
		addPlayer(10, 44, widthApp-20, heightApp-269);
		addSlider(0, 1000, 0, "Position", 10, heightApp-219, widthApp-20, 29);

		timeLabel = new JLabel("00:00:00:000");
		timeLabel.setBounds(20, heightApp-184, 90, 32);
		panel.add(timeLabel);
		
		initIcons();
		sv = new JButton(slowIcon);
		addIconButton(130, heightApp-184, 32, 32, sv);
		sv.setActionCommand("sv");
		sv.setEnabled(false);
		
		lf = new JButton(lastIcon);
		addIconButton(200, heightApp-184, 32, 32, lf);
		lf.setActionCommand("lf");
		lf.setEnabled(false);
		
		pausePlay = new JButton(pauseIcon);
		addIconButton(270, heightApp-184, 32, 32, pausePlay);
		pausePlay.setActionCommand("pp");
		pausePlay.setEnabled(false);
		
		nf = new JButton(nextIcon);
		addIconButton(340, heightApp-184, 32, 32, nf);
		nf.setActionCommand("nf");
		nf.setEnabled(false);
		
		fv = new JButton(fastIcon);
		addIconButton(410, heightApp-184, 32, 32, fv);
		fv.setActionCommand("fv");
		fv.setEnabled(false);
		
		bFG = new Button("Grab Frame");
		addButton(widthApp-252, heightApp-189, 135, 50, bFG);
		bFG.setEnabled(false);
		
		if(RuntimeUtil.isMac()){
			separator = new JSeparator();
			separator.setBounds(10, heightApp-140, widthApp-20, 12);
			panel.add(separator);
			separator.setEnabled(false);
		}
		
		label = new Label("Grabbed Frames");
		label.setBounds(10, heightApp-133, 107, 17);
		panel.add(label);
		
		panelFrames = new JScrollPane();
		panelFrames.setBounds(10, heightApp-115, widthApp-20, 145);
		panelFrames.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		panelFrames.setBackground(Color.darkGray);
		
		pa = new JPanel();
		panelFrames.setViewportView(pa);
		
		panel.add(panelFrames);

		bES = new Button("Export Stack");
		addButton(10, heightApp+40, 101, 28, bES);
		
		add(panel);
		setBounds(100, 100, widthApp, heightApp+100);
		setResizable(false);
		setVisible(true);
	}

	private void addButton(int x, int y, int width, int height, Button button){
		button.addActionListener(this);
		button.addKeyListener(IJ.getInstance());
		button.setBounds(x, y, width, height);
		panel.add(button);
	}
	
	private void addIconButton(int x, int y, int width, int height, JButton button) {
		button.setBorderPainted(false);
		button.setContentAreaFilled(false);
		button.setBounds(x, y, width, height);
		button.addActionListener(this);
		button.addKeyListener(IJ.getInstance());
		panel.add(button);
	}
	
	private void addFilePathTextField() {
		tfpath = new JTextField();
		tfpath.setToolTipText("Filepath to file you want to open.");
		tfpath.setBounds(10, 10, 70, 28);
		panel.add(tfpath);
		tfpath.setColumns(10);
		tfpath.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				bOpenVideo.setBounds(400, 10, 55, 29);
				bOpen.setBounds(342, 10, 55, 28);
				tfpath.setBounds(10, 10, 329, 28);
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(tfpath.getText().equals("")){					
					tfpath.setBounds(10, 10, 70, 28);
					bOpen.setBounds(82, 10, 55, 28);
					bOpenVideo.setBounds(140, 10, 55, 29);
				}
			}
		});
		tfpath.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				if(tfpath.getText().equals("")){
					bOpen.setEnabled(false);
				}else{
					bOpen.setEnabled(true);
				}
			}
		});
	}
	
	private void initIcons() {
		playIcon = new ImageIcon(getClass().getResource("play.png"));
		pauseIcon = new ImageIcon(getClass().getResource("pause.png"));
		lastIcon = new ImageIcon(getClass().getResource("first.png"));
		nextIcon = new ImageIcon(getClass().getResource("last.png"));
		fastIcon = new ImageIcon(getClass().getResource("next.png"));
		slowIcon = new ImageIcon(getClass().getResource("previous.png"));
	}
	
	private void addPlayer(int x, int y, int width, int height) {
		panelVideo = new Panel();
		panelVideo.add(logic.getMediaPlayerComponent());
		panelVideo.setLayout(new GridLayout(1, 1, 5, 5));
		panelVideo.setBounds(x, y, width, height);
		panel.add(panelVideo);
	}
	
	private void addSlider(int min, int max, int val, String Texto,
			int x, int y, int width, int height) {
		position = new JSlider();
		position.setMinimum(min);
		position.setMaximum(max);
		position.setValue(val);
		position.setToolTipText(Texto);
		position.setBounds(x, y, width, height);
		panel.add(position);
		position.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				logic.checkMediaPlayerIsPlaying();
				updateposition();
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				updateposition();
			}
			private void updateposition() {
				logic.updatePosition(position.getValue());
				pausePlay.setIcon(pauseIcon);
			}
		});
		
//		position.addChangeListener(new ChangeListener() {
//		      public void stateChanged(ChangeEvent evt) {
//		        JSlider slider = (JSlider) evt.getSource();
//		        if (!slider.getValueIsAdjusting()) {
//		        	logic.checkMediaPlayerIsPlaying();
//					logic.updatePosition(position.getValue());
//					pp.setIcon(pauseIcon);
//		        }
//		      }
//		    });
	}
	
	public void actionPerformed(ActionEvent e) {
		String label = e.getActionCommand();
		if (label == null)
			return;
		if (label.equals("Open Video")) {
			open();
			openVideo();
		} else if (label.equals("Open")) {
			if(logic.openVideoPath(tfpath.getText())) openVideo();
			else pausePlay.setIcon(playIcon);
		} else if (label.equals("Grab Frame")) {
			addFrame();
		} else if(label.equals("About Video")){
		    getAboutVideo();
		} else if (label.equals("Preferences")) {	
		    getPreferences();
		} else if (label.equals("Export Stack")){
			logic.exportStack();
		} else if (label.equals("lf")){
			logic.lastFrame();
			pausePlay.setIcon(playIcon);
		} else if (label.equals("nf")){
			logic.nextFrame();
			pausePlay.setIcon(playIcon);
		} else if (label.equals("pp")){
			getPausePlayAction();
		} else if (label.equals("sv")){
			logic.slowMedia();
		} else if (label.equals("fv")){
			logic.fastMedia();
		} 
	}

	public void open() {
		OpenDialog od = new OpenDialog("Open File", "");
		String fileName = od.getFileName();
		if (fileName == null)
			return;
		String fileDir = od.getDirectory();
		logic.setMrl(fileDir + fileName);
		tfpath.setText(logic.getMrl());
		bOpenVideo.setBounds(400, 10, 55, 29);
		bOpen.setBounds(342, 10, 55, 28);
		tfpath.setBounds(10, 10, 329, 28);
	}
	
	private void openVideo() {
		if(logic.playMedia()){
			bAbout.setEnabled(true);
			sv.setEnabled(true);
			lf.setEnabled(true);
			pausePlay.setEnabled(true);
			nf.setEnabled(true);
			fv.setEnabled(true);
			bFG.setEnabled(true);
			bOpen.setEnabled(true);
			separator.setEnabled(true);
			executorService.scheduleAtFixedRate(new UpdateRunnable(), 0L, 1L, TimeUnit.MILLISECONDS);
		}	
	}
	
	class UpdateRunnable implements Runnable {
	    
	    @Override
	    public void run() {
	      if(logic.endOfFile()){
	    	  pausePlay.setIcon(playIcon);
	      }
	      
	      SwingUtilities.invokeLater(new Runnable() {
	        @Override
	        public void run() {
	        	position.setValue(logic.getPosition());
	        	timeLabel.setText(logic.getStringTime());
	        }
	      });
	    }
	}
	
	@Override
	public void windowClosing(WindowEvent e) {
		logic.getMediaPlayerComponent().getMediaPlayer().stop();
		logic.getMediaPlayerComponent().getMediaPlayer().release();
		super.windowClosing(e);
	}
	
	private void addFrame() {
		JButton te = logic.grabFrame();
		if(te!=null){
			te.setVerticalTextPosition(AbstractButton.BOTTOM);
			te.setHorizontalTextPosition(AbstractButton.CENTER);
			te.setBorderPainted(false);
			te.setContentAreaFilled(false);
			te.setVisible(true);
			//pa.add(te);
			int a = logic.getFramePosition(Float.parseFloat(te.getText()));
			pa.add(te, a);
			pa.updateUI();
		}
	}
	
	private void getAboutVideo() {
		HashMap<String, Integer> hm = logic.aboutVideo();
		GenericDialog gd = new GenericDialog("About Video");
		gd.addMessage("Video Details\n");
		if(hm.get("fps")==0){
			gd.addMessage("Frames per Second: Undifined\n");
		}else{gd.addMessage("Frames per Second: "+hm.get("fps")+"\n");}
		gd.addMessage("Resolution: "+hm.get("width")+"x"+hm.get("height")+" pixels\n");
		gd.addMessage("Time: "+hm.get("time")+" s\n");
	    gd.showDialog();
	    if (gd.wasCanceled()) return;
	}
	
	private void getPreferences() {
		GenericDialog gd = new GenericDialog("Options");
		gd.addMessage("Aplication Options:\n");
	    gd.addNumericField("Width: ", widthApp, 0);
	    gd.addNumericField("Height: ", heightApp, 0);
	    gd.showDialog();
	    if (gd.wasCanceled()) return;
	    widthApp = (int)gd.getNextNumber();
	    heightApp = (int)gd.getNextNumber();
	    reloadComponents();
	}
	
	private void reloadComponents() {
		
		if(tfpath.getText().equals("")){					
			tfpath.setBounds(10, 10, 70, 28);
			bOpen.setBounds(82, 10, 55, 28);
			bOpenVideo.setBounds(140, 10, 55, 29);
		}else{
			bOpenVideo.setBounds(400, 10, 55, 29);
			bOpen.setBounds(342, 10, 55, 28);
			tfpath.setBounds(10, 10, 329, 28);			
		}
		
		bAbout.setBounds(widthApp-218, 10, 101, 28);
		bPref.setBounds(widthApp-111, 10, 101, 28);
		
		panelVideo.setBounds(10, 44, widthApp-20, heightApp-269);;
		position.setBounds(10, heightApp-219, widthApp-20, 29);
		
		bFG.setBounds(widthApp-252, heightApp-189, 135, 50);
		
		sv.setBounds(130, heightApp-184, 32, 32);
		lf.setBounds(200, heightApp-184, 32, 32);
		pausePlay.setBounds(270, heightApp-184, 32, 32);
		nf.setBounds(340, heightApp-184, 32, 32);
		fv.setBounds(410, heightApp-184, 32, 32);
		
		separator.setBounds(10, heightApp-140, widthApp-20, 12);
		label.setBounds(10, heightApp-133, 107, 17);
		panelFrames.setBounds(10, heightApp-115, widthApp-20, 145);
		
		bES.setBounds(10, heightApp+40, 101, 28);
		
		frame.setBounds(100, 100, widthApp, heightApp+100);
	}
	
	private void getPausePlayAction() {
		if(pausePlay.getIcon()==pauseIcon){
			logic.pause();
			pausePlay.setIcon(playIcon);
		}else{
			logic.play();
			pausePlay.setIcon(pauseIcon);
		}
	}

}
